# Project Report: test-skip

Project ID: 1863fa88-5b3e-4493-bf04-5515eda215af
Generated: 2026-01-01T20:00:03.344921Z

## Compilation

- Total attestations: 3
- Processed: 1
- Skipped: 2
- Bytes: 1
- Kernel step: 1
- Kernel state: aaa5c5 (index 43612)
- Last byte: 0x3a

### Skipped Attestations

- Index 1 (ID: invalid_001): invalid unit: invalid_unit
- Index 2 (ID: invalid_002): invalid domain: invalid_domain

## Accounting

### THM Totals
- GTD: 1
- IVD: 0
- IAD: 0
- IID: 0

### Gyroscope Totals
- GM: 0
- ICu: 0
- IInter: 0
- ICo: 0

## Ledger & Apertures

- Economy aperture: 0.500000
- Employment aperture: 0.000000
- Education aperture: 0.000000
