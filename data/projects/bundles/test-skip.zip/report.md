# Project Report: test-skip

Generated: 2025-12-31T00:18:57.474687Z

## Compilation

- Total attestations: 3
- Processed: 1
- Skipped: 2
- Bytes: 1
- Kernel step: 1
- Kernel state: aaaefe (index 43759)
- Last byte: 0x01

### Skipped Attestations

- Index 1 (ID: invalid_001): invalid unit: invalid_unit
- Index 2 (ID: invalid_002): invalid domain: invalid_domain

## Accounting

### THM Totals
- GTD: 1
- IVD: 0
- IAD: 0
- IID: 0

### Gyroscope Totals
- GM: 0
- ICu: 0
- IInter: 0
- ICo: 0

## Ledger & Apertures

- Economy aperture: 0.500000
- Employment aperture: 0.000000
- Education aperture: 0.000000
