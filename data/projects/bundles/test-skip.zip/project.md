---
project_name: Test Skip
project_slug: test-skip
sponsor: Test Lab
created_at: 2025-01-01 00:00:00+00:00
attestations:
- id: valid_001
  unit: daily
  domain: economy
  human_mark: Governance Traceability Displacement
- id: invalid_001
  unit: invalid_unit
  domain: economy
  human_mark: Governance Traceability Displacement
- id: invalid_002
  unit: daily
  domain: invalid_domain
  human_mark: Governance Traceability Displacement
computed:
  last_synced_at: '2026-01-01T20:00:03.344921Z'
  apertures:
    economy: 0.5
    employment: 0.0
    education: 0.0
  event_count: 1
  kernel:
    step: 1
    state_index: 43612
    state_hex: aaa5c5
---

# Test Skip Project
