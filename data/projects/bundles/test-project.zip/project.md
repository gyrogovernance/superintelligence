---
project_name: Test Project
project_slug: test-project
sponsor: Test Lab
created_at: 2025-01-01 00:00:00+00:00
attestations:
- id: att_001
  unit: daily
  domain: economy
  human_mark: Governance Traceability Displacement
  gyroscope_work: Governance Management
  evidence_links: []
  note: Test attestation
- id: att_002
  unit: sprint
  domain: employment
  human_mark: Information Variety Displacement
  gyroscope_work: Information Curation
  evidence_links: []
  note: Sprint attestation
computed:
  last_synced_at: '2025-12-31T00:18:57.458665Z'
  apertures:
    economy: 0.5
    employment: 0.5
    education: 0.0
  event_count: 2
  kernel:
    step: 5
    state_index: 35471
    state_hex: 8a88f8
---

# Test Project

Test project description.
