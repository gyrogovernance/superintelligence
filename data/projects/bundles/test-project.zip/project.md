---
project_name: Test Project
project_slug: test-project
sponsor: Test Lab
created_at: 2025-01-01 00:00:00+00:00
attestations:
- id: att_001
  unit: daily
  domain: economy
  human_mark: Governance Traceability Displacement
  gyroscope_work: Governance Management
  evidence_links: []
  note: Test attestation
- id: att_002
  unit: sprint
  domain: employment
  human_mark: Information Variety Displacement
  gyroscope_work: Information Curation
  evidence_links: []
  note: Sprint attestation
computed:
  last_synced_at: '2026-01-01T20:00:03.328988Z'
  apertures:
    economy: 0.5
    employment: 0.5
    education: 0.0
  event_count: 2
  kernel:
    step: 5
    state_index: 25134
    state_hex: 6262e2
---

# Test Project

Test project description.
