# Project Report: test-project

Generated: 2025-12-31T00:18:57.458665Z

## Compilation

- Total attestations: 2
- Processed: 2
- Skipped: 0
- Bytes: 5
- Kernel step: 5
- Kernel state: 8a88f8 (index 35471)
- Last byte: 0x04

## Accounting

### THM Totals
- GTD: 1
- IVD: 4
- IAD: 0
- IID: 0

### Gyroscope Totals
- GM: 1
- ICu: 4
- IInter: 0
- ICo: 0

## Ledger & Apertures

- Economy aperture: 0.500000
- Employment aperture: 0.500000
- Education aperture: 0.000000
