# Project Report: test-project

Project ID: bcd5ebb9-5388-4464-a5f2-c379a9c53149
Generated: 2026-01-01T20:00:03.327983Z

## Compilation

- Total attestations: 2
- Processed: 2
- Skipped: 0
- Bytes: 5
- Kernel step: 5
- Kernel state: 6262e2 (index 25134)
- Last byte: 0x06

## Accounting

### THM Totals
- GTD: 1
- IVD: 4
- IAD: 0
- IID: 0

### Gyroscope Totals
- GM: 1
- ICu: 4
- IInter: 0
- ICo: 0

## Ledger & Apertures

- Economy aperture: 0.500000
- Employment aperture: 0.500000
- Education aperture: 0.000000
