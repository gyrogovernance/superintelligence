# Project Report: basil

Project ID: dedc9c7c-0951-4150-b967-559bab682529
Generated: 2026-01-07T16:25:32.813688Z

## Compilation

- Total attestations: 228
- Processed: 228
- Skipped: 0
- Bytes: 912
- Kernel step: 912
- Kernel state: 9c9d3d (index 40147)
- Last byte: 0x5d

## Accounting

### THM Totals
- GTD: 56
- IVD: 4
- IAD: 4
- IID: 0

### Gyroscope Totals
- GMT: 48
- ICV: 120
- IIA: 120
- ICI: 560

### Attestation Distribution by Domain

- Economy: 24 displacement, 284 alignment
- Employment: 20 displacement, 284 alignment
- Education: 20 displacement, 280 alignment

## Ledger & Apertures

- Economy aperture: 0.500000
- Employment aperture: 0.500000
- Education aperture: 0.454545
