# Project Report: basil

Project ID: dedc9c7c-0951-4150-b967-559bab682529
Generated: 2026-01-04T22:34:51.835146Z

## Compilation

- Total attestations: 1102
- Processed: 1102
- Skipped: 0
- Bytes: 1102
- Kernel step: 1102
- Kernel state: b8b4f4 (index 47183)
- Last byte: 0xe3

## Accounting

### THM Totals
- GTD: 0
- IVD: 1
- IAD: 1
- IID: 0

### Gyroscope Totals
- GMT: 900
- ICV: 30
- IIA: 30
- ICI: 140

### Attestation Distribution by Domain

- Economy: 1 displacement, 367 alignment
- Employment: 1 displacement, 367 alignment
- Education: 0 displacement, 366 alignment

## Ledger & Apertures

- Economy aperture: 0.500000
- Employment aperture: 0.500000
- Education aperture: 0.000000
