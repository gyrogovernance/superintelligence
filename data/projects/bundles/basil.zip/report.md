# Project Report: basil

Project ID: dedc9c7c-0951-4150-b967-559bab682529
Generated: 2026-01-04T14:39:08.716735Z

## Compilation

- Total attestations: 47
- Processed: 47
- Skipped: 0
- Bytes: 47
- Kernel step: 47
- Kernel state: 363f3f (index 14067)
- Last byte: 0xf4

## Accounting

### THM Totals
- GTD: 10
- IVD: 2
- IAD: 1
- IID: 1

### Gyroscope Totals
- GMT: 13
- ICV: 7
- IIA: 12
- ICI: 1

### Attestation Distribution by Domain

- Economy: 10 displacement, 22 alignment
- Employment: 4 displacement, 11 alignment
- Education: 0 displacement, 0 alignment

## Ledger & Apertures

- Economy aperture: 0.500000
- Employment aperture: 0.583333
- Education aperture: 0.000000
